package com.autoloan.supply.model;

import org.springframework.data.repository.CrudRepository;




public interface ItemOrderRepository extends CrudRepository<ItemOrderEntity, String> {
    
    
    
}