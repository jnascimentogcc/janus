package com.autoloan.supply.model;

import org.springframework.data.repository.CrudRepository;




public interface GroupProductRepository extends CrudRepository<GroupProductEntity, String> {
    
    
    
}